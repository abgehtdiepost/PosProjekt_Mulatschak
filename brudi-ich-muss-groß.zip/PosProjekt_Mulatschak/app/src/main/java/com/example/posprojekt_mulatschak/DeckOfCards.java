package com.example.posprojekt_mulatschak;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.ArrayList;
import java.util.List;

public class DeckOfCards {
    private ArrayList<Card> deck;
    private Bitmap backOfCardImage;

    public DeckOfCards(){
        Bitmap temp = BitmapFactory.decodeFile("weli.jpg");
        Card c = new Card("weli",3,6,temp);

    }

    public ArrayList<Card> getDeck() {
        return deck;
    }

    public void setDeck(ArrayList<Card> deck) {
        this.deck = deck;
    }

    public Bitmap getBackOfCardImage() {
        return backOfCardImage;
    }

    public void setBackOfCardImage(Bitmap backOfCardImage) {
        this.backOfCardImage = backOfCardImage;
    }

    public Card getCard(int i){
        return this.deck.get(i);
    }

    public Bitmap getPicture(int i){
        return this.deck.get(i).getCadImage();
    }
}
