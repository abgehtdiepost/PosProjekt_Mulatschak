package com.example.posprojekt_mulatschak;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    DatabaseReference mDatabase;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.start);

        mDatabase = FirebaseDatabase.getInstance().getReference("cards");
        EditText player1 = findViewById(R.id.player1_pt);
        String player1Name = player1.getText().toString();
        EditText player2 = findViewById(R.id.player2_pt);
        String player2Name = player1.getText().toString();
        EditText player3 = findViewById(R.id.player3_pt);
        String player3Name = player1.getText().toString();
        EditText player4 = findViewById(R.id.player4_pt);
        String player4Name = player1.getText().toString();
        DeckOfCards deck = new DeckOfCards();

        //ImageView reartest = findViewById(R.id.imageView);
       // reartest.setImageBitmap(deck.getPicture(0));
        //ImageView testCards = findViewById(R.id.testCard);
        //int[] images = {R.drawable.herz8,R.drawable.herz9,R.drawable.herz10,R.drawable.herzkoenig};
        //Random rand = new Random();

        //testCards.setImageResource(R.drawable.eichel6);



    }

    public static void shuffle () {

    }

    public void onStartClick(View view) {
        //String name = findViewById(R.id.player1_pt).toString();
        //mDatabase.child("user").child("1").setValue(null);
        //DatabaseReference myRef = database.getReference("message");
        //myRef.setValue("Hello World");
        DatabaseReference myRef = database.getReference("name");
        myRef.setValue(findViewById(R.id.player1_pt).toString());
        setContentView(R.layout.hands);
        fillCards();
        DatabaseReference card1 = database.getInstance().getReference("card1");
        card1.child("card1").setValue((Object) findViewById(R.id.imageView).toString());
        DatabaseReference card2 = database.getInstance().getReference("card2");
        card2.child("card2").setValue((Object) findViewById(R.id.imageView2).toString());
        DatabaseReference card3 = database.getInstance().getReference("card3");
        card3.child("card3").setValue((Object) findViewById(R.id.imageView3).toString());
        DatabaseReference card4 = database.getInstance().getReference("card4");
        card4.child("card4").setValue((Object) findViewById(R.id.imageView4).toString());
        DatabaseReference card5 = database.getInstance().getReference("card5");
        card5.child("card5").setValue((Object) findViewById(R.id.imageView5).toString());
        //card1.setValue(findViewById(R.id.imageView).toString());
    }

    public void fillCards () {
        int[] pics = {R.drawable.eichelacht, R.drawable.eichelkoenig, R.drawable.eichelneun, R.drawable.eichelober, R.drawable.eichelsau, R.drawable.eichelsechs, R.drawable.eichelsieben, R.drawable.eichelunter, R.drawable.eichelzehn,
                R.drawable.herzacht, R.drawable.herzkoenig, R.drawable.herzneun, R.drawable.herzober, R.drawable.herzsau, R.drawable.herzsieben, R.drawable.herzunter, R.drawable.herzzehn,
                R.drawable.laubacht, R.drawable.laubkoenig, R.drawable.laubneun, R.drawable.laubober, R.drawable.laubsau, R.drawable.laubsechs, R.drawable.laubsieben, R.drawable.laubunter, R.drawable.laubzehn,
                R.drawable.schellenacht, R.drawable.schellenkoenig, R.drawable.schellenneun, R.drawable.schellenober, R.drawable.schellensau, R.drawable.schellensechs, R.drawable.schellensieben, R.drawable.schellenunter, R.drawable.schellenzehn};
        ImageView image = (ImageView) findViewById(R.id.imageView);
        ImageView image2 = (ImageView) findViewById(R.id.imageView2);
        ImageView image3 = (ImageView) findViewById(R.id.imageView3);
        ImageView image4 = (ImageView) findViewById(R.id.imageView4);
        ImageView image5 = (ImageView) findViewById(R.id.imageView5);
        Random r = new Random();
        int i = r.nextInt(pics.length);
        image.setImageResource(pics[i]);
        i = r.nextInt(pics.length);
        image2.setImageResource(pics[i]);
        i = r.nextInt(pics.length);
        image3.setImageResource(pics[i]);
        i = r.nextInt(pics.length);
        image4.setImageResource(pics[i]);
        i = r.nextInt(pics.length);
        image5.setImageResource(pics[i]);


    }
    public void onStichansageClick(View view) {
        final DatabaseReference Ref = database.getReference("card 1");

        //image.setImageResource((Integer.valueOf(String.valueOf(database.getReference("card 1")))));
        setContentView(R.layout.stichansage);
        Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //String data = snapshot.getValue(String.class);
                //ImageView image = (ImageView) findViewById(R.id.imageView8);
                //image.setImageResource(Integer.valueOf(data));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void onTrumpffarbeClick(View view) {
        if (!findViewById(R.id.stiche_tv).toString().equals("")) {
            setContentView(R.layout.trumpffarbe);
        }
    }


}
